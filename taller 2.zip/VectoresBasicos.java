import java.util.Scanner;

public class VectoresBasicos {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] numeros = new int[5];

        System.out.println("--- Ingrese 5 números enteros ---");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();
        }

        System.out.println("\n--- Números ingresados ---");
        for (int numero : numeros) {
            System.out.println(numero);
        }

        sc.close();
    }
}