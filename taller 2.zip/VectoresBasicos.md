# VectoresBasicos.java

Este programa:
1. Declara un vector de tamaño 5.
2. Solicita al usuario que ingrese 5 números.
3. Imprime los números ingresados.

## Puntos clave:
- Uso del ciclo `for` para recorrer el vector.
- Uso de `Scanner` para entrada por teclado.