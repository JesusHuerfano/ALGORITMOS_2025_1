import java.util.Scanner;

public class SumaVector {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] numeros = new int[5];
        int suma = 0;

        System.out.println("--- Ingrese 5 números enteros ---");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();
            suma += numeros[i];
        }

        System.out.println("\nLa suma total es: " + suma);
        sc.close();
    }
}