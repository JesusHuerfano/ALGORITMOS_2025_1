# SumaVector.java

Este programa:
1. Crea un vector de 5 elementos.
2. Pide al usuario los valores.
3. Calcula e imprime la suma de todos los elementos.

## Puntos clave:
- Uso de `+=` para acumular valores.
- Estructura de bucle `for` tradicional.