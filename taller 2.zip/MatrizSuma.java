import java.util.Scanner;

public class MatrizSuma {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[][] matriz = new int[2][2];
        int suma = 0;

        System.out.println("--- Ingrese los valores de la matriz 2x2 ---");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print("Elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = sc.nextInt();
                suma += matriz[i][j];
            }
        }

        System.out.println("\nLa suma de todos los elementos es: " + suma);
        sc.close();
    }
}