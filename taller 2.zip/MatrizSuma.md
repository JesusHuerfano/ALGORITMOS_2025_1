# MatrizSuma.java

Este programa:
1. Solicita al usuario que ingrese los valores de una matriz 2x2.
2. Calcula la suma total de sus elementos.

## Puntos clave:
- Uso de bucles anidados para recorrer la matriz.
- Acumulación de la suma dentro del segundo bucle.