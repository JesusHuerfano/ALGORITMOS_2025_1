# MayorMenorVector.java

Este programa:
1. Solicita 5 valores enteros al usuario.
2. Determina el número mayor y el menor del vector.

## Puntos clave:
- Comparación entre elementos con `if`.
- Inicialización de mayor/menor con el primer valor.