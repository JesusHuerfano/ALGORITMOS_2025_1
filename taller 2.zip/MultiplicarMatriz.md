# MultiplicarMatriz.java

Este programa:
1. Solicita al usuario ingresar los valores para una matriz de 3x3.
2. Recorre todos los elementos.
3. Multiplica cada elemento por 2 y muestra la matriz resultante.

## Puntos clave:
- Uso de bucles anidados para recorrer matrices.
- Operaciones aritméticas dentro del `System.out.print`.